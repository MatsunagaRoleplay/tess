# Deployment Guide - Toko Layanan Digital

This Flask application is designed to be compatible with all major web hosting platforms. Below are instructions for various hosting environments.

## Files Overview

- `app.py` - Main Flask application
- `main.py` - Entry point for Replit and similar platforms
- `wsgi.py` - WSGI configuration for standard hosting
- `passenger_wsgi.py` - For Passenger-based hosting (cPanel, Namecheap, etc.)
- `app.wsgi` - For Apache mod_wsgi
- `index.py` - Alternative entry point for some hosting providers
- `.htaccess` - Apache configuration
- `Procfile` - For Heroku deployment
- `runtime.txt` - Python version specification

## 1. Shared Hosting (cPanel, Namecheap, Hostinger, etc.)

### Method 1: Using Passenger (Recommended)
1. Upload all files to your public_html or domain folder
2. Ensure `passenger_wsgi.py` is in the root directory
3. Set Python version to 3.11+ in hosting control panel
4. Install dependencies via pip in hosting terminal:
   ```bash
   pip install flask gunicorn
   ```
5. Website should be accessible immediately

### Method 2: Using CGI
1. Upload all files to public_html
2. Ensure `.htaccess` is in the root directory
3. Make Python files executable:
   ```bash
   chmod +x *.py
   ```
4. Access via `yourdomain.com/main.py`

## 2. VPS/Dedicated Server

### Using Gunicorn (Recommended)
```bash
# Install dependencies
pip install flask gunicorn

# Run with Gunicorn
gunicorn --bind 0.0.0.0:5000 wsgi:application

# Or for production
gunicorn --bind 0.0.0.0:80 --workers 4 wsgi:application
```

### Using Apache + mod_wsgi
```apache
# Add to Apache virtual host
WSGIDaemonProcess flaskapp python-path=/path/to/your/app
WSGIProcessGroup flaskapp
WSGIScriptAlias / /path/to/your/app/app.wsgi
```

## 3. Cloud Platforms

### Heroku
1. Create `Procfile` (already included)
2. Deploy via Git:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   heroku create your-app-name
   git push heroku main
   ```

### Python Anywhere
1. Upload files to `/home/yourusername/mysite`
2. In Web tab, set:
   - Source code: `/home/yourusername/mysite`
   - WSGI configuration file: `/home/yourusername/mysite/wsgi.py`

### Google App Engine
1. Create `app.yaml`:
   ```yaml
   runtime: python39
   entrypoint: gunicorn -b :$PORT wsgi:application
   ```

## 4. Environment Variables

Set these environment variables in your hosting platform:
- `SESSION_SECRET` - Secret key for Flask sessions (optional, has fallback)

## 5. Static Files

All static files (CSS, JS, images) are served from the `static/` directory. Most hosting platforms will serve these automatically.

## 6. Troubleshooting

### Common Issues:
1. **ImportError**: Ensure all dependencies are installed
2. **500 Error**: Check error logs, usually permission issues
3. **Static files not loading**: Verify static folder permissions
4. **Module not found**: Check Python path configuration

### Testing Locally:
```bash
python app.py
# Or
python main.py
# Or
gunicorn wsgi:application
```

## 7. Dependencies

The application requires:
- Flask (web framework)
- Python 3.8+ (3.11+ recommended)
- Standard library modules only (no database required)

## 8. Performance Tips

1. Enable gzip compression (included in .htaccess)
2. Set proper cache headers for static files
3. Use CDN for Bootstrap and Font Awesome
4. Consider using Gunicorn with multiple workers for high traffic

## 9. Security

- Change SESSION_SECRET in production
- Use HTTPS when possible
- Review .htaccess security headers
- Keep Flask updated

## Support

For hosting-specific issues, consult your hosting provider's documentation or contact their support team.